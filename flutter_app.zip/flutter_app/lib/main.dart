import "package:flutter/material.dart";

void main(){

  runApp(
    MaterialApp(
      title: "My First Flutter App In Flutter Created On Mahashivratri",
          home: Material(
             color: Colors.lightBlueAccent,
                child: Center(

                      child: Text("Happy mahashivratri",textDirection: TextDirection.ltr)
                )

         ),
    )



  );
}